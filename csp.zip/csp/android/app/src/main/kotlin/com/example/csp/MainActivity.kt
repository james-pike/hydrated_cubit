package com.example.csp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
